﻿namespace RecipeApp
{
    partial class MainMenu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listRecipes = new ListBox();
            MainLabel = new Label();
            SecondMainLabel = new Label();
            btnOpenApiRecipes = new Button();
            txtDetails = new TextBox();
            DetailsLabel = new Label();
            SuspendLayout();
            // 
            // listRecipes
            // 
            listRecipes.BackColor = SystemColors.ButtonHighlight;
            listRecipes.FormattingEnabled = true;
            listRecipes.ItemHeight = 15;
            listRecipes.Location = new Point(12, 102);
            listRecipes.Name = "listRecipes";
            listRecipes.Size = new Size(215, 244);
            listRecipes.TabIndex = 1;
            // 
            // MainLabel
            // 
            MainLabel.AutoSize = true;
            MainLabel.Font = new Font("Segoe UI", 20F);
            MainLabel.Location = new Point(261, 9);
            MainLabel.Name = "MainLabel";
            MainLabel.Size = new Size(274, 37);
            MainLabel.TabIndex = 2;
            MainLabel.Text = "Менеджер рецептов";
            // 
            // SecondMainLabel
            // 
            SecondMainLabel.AutoSize = true;
            SecondMainLabel.Font = new Font("Segoe UI", 15F);
            SecondMainLabel.Location = new Point(12, 71);
            SecondMainLabel.Name = "SecondMainLabel";
            SecondMainLabel.Size = new Size(215, 28);
            SecondMainLabel.TabIndex = 3;
            SecondMainLabel.Text = "Список всех рецептов";
            // 
            // btnOpenApiRecipes
            // 
            btnOpenApiRecipes.Location = new Point(477, 409);
            btnOpenApiRecipes.Name = "btnOpenApiRecipes";
            btnOpenApiRecipes.Size = new Size(144, 29);
            btnOpenApiRecipes.TabIndex = 4;
            btnOpenApiRecipes.Text = "Найти рецепты (API)";
            btnOpenApiRecipes.UseVisualStyleBackColor = true;
            btnOpenApiRecipes.Click += btnOpenApiRecipes_Click;
            // 
            // txtDetails
            // 
            txtDetails.Location = new Point(378, 102);
            txtDetails.Multiline = true;
            txtDetails.Name = "txtDetails";
            txtDetails.ReadOnly = true;
            txtDetails.ScrollBars = ScrollBars.Vertical;
            txtDetails.Size = new Size(308, 244);
            txtDetails.TabIndex = 5;
            // 
            // DetailsLabel
            // 
            DetailsLabel.AutoSize = true;
            DetailsLabel.Font = new Font("Segoe UI", 15F);
            DetailsLabel.Location = new Point(378, 71);
            DetailsLabel.Name = "DetailsLabel";
            DetailsLabel.Size = new Size(156, 28);
            DetailsLabel.TabIndex = 6;
            DetailsLabel.Text = "Детали рецепта";
            // 
            // MainMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(DetailsLabel);
            Controls.Add(txtDetails);
            Controls.Add(btnOpenApiRecipes);
            Controls.Add(SecondMainLabel);
            Controls.Add(MainLabel);
            Controls.Add(listRecipes);
            Name = "MainMenu";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button AddRecipeMenuBtn;
        private ListBox listRecipes;
        private Label MainLabel;
        private Label SecondMainLabel;
        private Button btnOpenApiRecipes;
        private TextBox txtDetails;
        private Label DetailsLabel;
    }
}
