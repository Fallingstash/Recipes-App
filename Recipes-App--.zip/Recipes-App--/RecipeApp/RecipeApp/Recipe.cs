﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace RecipeApp
{
    public class Recipe
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string ImageUrl { get; set; }
        public List<string> Ingredients { get; set; }
        public string Instructions { get; set; }
        public bool IsFromApi { get; set; }

        [JsonConstructor]
        public Recipe(int id, string title, string imageUrl, List<string> ingredients,
                     string instructions, bool isFromApi = false)
        {
            Id = id;
            Title = title;
            ImageUrl = imageUrl;
            Ingredients = ingredients;
            Instructions = instructions;
            IsFromApi = isFromApi;
        }

        public override string ToString() => $"{Title} {(IsFromApi ? "(API)" : "")}";
    }
}
