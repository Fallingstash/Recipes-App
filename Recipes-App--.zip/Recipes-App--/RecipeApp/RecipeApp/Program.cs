namespace RecipeApp
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            try
            {
                Application.Run(new MainMenu());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"����������� ������: {ex.Message}");
                File.WriteAllText("error.log", $"{DateTime.Now}: {ex}");
            }
        }
    }
}